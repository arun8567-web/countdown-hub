# ExamOra Android project

ExamOra is a black-to-neon-blue/purple custom countdown app and Android home-screen widget. It supports multiple named exam/event countdowns (JEE, NEET, SSC, Diwali, birthdays, deadlines), a daily motivational quote, selectable event colours, and selectable widget background colours. The existing application ID `com.jeewarrior.countdown` is retained.

## Build using only an Android phone
1. Download this ZIP and keep it in Downloads.
2. Open your GitHub repository in Chrome. Upload this ZIP to the repository root, replacing the older `ExamOra_Phone_Build_Project.zip` if prompted.
3. Replace `.github/workflows/build-apk.yml` with the workflow in this project, or create it at that exact path with the included contents. It extracts the ZIP and builds the APK online.
4. Open Actions → Build ExamOra APK → Run workflow.
5. When successful, open the run and download artifact `examora-debug-apk`.
6. Extract the artifact ZIP and install `app-debug.apk`.
7. Add the widget: long-press home screen → Widgets → ExamOra / ExamOra Countdown.

## Update and saved data
The application ID remains the same, which is needed for an in-place update. However, debug APK signing keys can differ between GitHub runner builds; if Android rejects the update due to a signature mismatch, uninstall the old app before installing ExamOra (this may erase locally saved countdowns). Record event names and dates first.

## Notes
This ZIP is source code plus a GitHub Actions workflow, not a prebuilt APK. The GitHub Actions run compiles it online.
