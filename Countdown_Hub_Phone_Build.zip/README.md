# Countdown Hub — Android project

Generic black/red countdown app and home-screen widget. Add JEE, NEET, SSC, board exams, Diwali, birthdays, or any event with its own name and date.

## Build an APK using only your Android phone
1. Extract this ZIP using your phone's file manager.
2. Sign in to GitHub in your phone browser and create a repository.
3. Upload the extracted project files/folders, preserving the folder structure. Make sure `.github/workflows/build-apk.yml` is included.
4. Open the repository's **Actions** tab.
5. Select **Build Countdown Hub APK** → **Run workflow**.
6. Wait for the run to finish successfully.
7. Open the completed run and download the `countdown-hub-debug-apk` artifact.
8. Extract that artifact ZIP and install `app-debug.apk`. Android may ask you to allow installs from the browser/file manager.

## Add the home-screen widget
After installing, long-press an empty home-screen area → Widgets → Countdown Hub/JEE Countdown → drag the widget onto the home screen.

## Important
This ZIP is source code plus an online build workflow, not a prebuilt APK. GitHub builds the APK after you run the workflow. It requires a GitHub account and internet access.
