package com.jeewarrior.countdown;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class EventStore {
    public static final String PREF = "events_store";
    public static final String KEY = "events_json";
    public static class Event {
        public String title, date;
        public Event(String t, String d) { title=t; date=d; }
    }
    public static List<Event> get(Context c) {
        SharedPreferences p=c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String raw=p.getString(KEY, null);
        List<Event> out=new ArrayList<>();
        if(raw==null) {
            out.add(new Event("My First Event", "2027-01-20"));
            save(c,out); return out;
        }
        try {
            JSONArray a=new JSONArray(raw);
            for(int i=0;i<a.length();i++) {
                JSONObject o=a.getJSONObject(i);
                out.add(new Event(o.getString("title"),o.getString("date")));
            }
        } catch(Exception ignored) {}
        if(out.isEmpty()) out.add(new Event("My First Event","2027-01-20"));
        return out;
    }
    public static void save(Context c,List<Event> events) {
        JSONArray a=new JSONArray();
        try {
            for(Event e:events) { JSONObject o=new JSONObject(); o.put("title",e.title); o.put("date",e.date); a.put(o); }
        } catch(Exception ignored) {}
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(KEY,a.toString()).apply();
    }
    public static Event next(Context c) {
        List<Event> events=get(c); Event best=null; long now=System.currentTimeMillis(), bestDiff=Long.MAX_VALUE;
        for(Event e:events) {
            try {
                long t=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(e.date).getTime()+86399999L;
                long d=t-now;
                if(d>=-86400000L && d<bestDiff) { best=e; bestDiff=Math.max(0,d); }
            } catch(Exception ignored) {}
        }
        if(best==null) {
            for(Event e:events) try {
                long t=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(e.date).getTime();
                long d=Math.abs(t-now); if(d<bestDiff){best=e;bestDiff=d;}
            } catch(Exception ignored) {}
        }
        return best==null?new Event("My First Event","2027-01-20"):best;
    }
}
