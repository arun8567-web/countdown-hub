package com.jeewarrior.countdown;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CountdownWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for(int id:ids) update(context,manager,id);
    }
    public static void update(Context c, AppWidgetManager manager, int id) {
        RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.countdown_widget);
        EventStore.Event e=EventStore.next(c);
        long target=0;
        try { target=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(e.date).getTime(); } catch(Exception ignored) {}
        long today=java.util.Calendar.getInstance().getTimeInMillis();
        long days=Math.max(0,(target-today+86399999L)/86400000L);
        v.setTextViewText(R.id.widget_title,e.title);
        v.setTextViewText(R.id.widget_days,String.valueOf(days));
        try {
            Date d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(e.date);
            v.setTextViewText(R.id.widget_date,new SimpleDateFormat("d MMMM yyyy",Locale.ENGLISH).format(d));
        } catch(Exception ignored) { v.setTextViewText(R.id.widget_date,e.date); }
        v.setTextViewText(R.id.widget_quote,"Tap to manage events");
        Intent i=new Intent(c,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.widget_title,pi); v.setOnClickPendingIntent(R.id.widget_days,pi); v.setOnClickPendingIntent(R.id.widget_date,pi);
        manager.updateAppWidget(id,v);
    }
    public static void refreshAll(Context c) {
        AppWidgetManager m=AppWidgetManager.getInstance(c);
        int[] ids=m.getAppWidgetIds(new android.content.ComponentName(c,CountdownWidgetProvider.class));
        for(int id:ids) update(c,m,id);
    }
}
