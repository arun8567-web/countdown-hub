package com.jeewarrior.countdown;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout list; EditText titleInput; TextView dateButton; Calendar selected=Calendar.getInstance();
    String chosenDate="2027-01-20";
    int red=Color.rgb(255,64,88), white=Color.WHITE, muted=Color.rgb(185,185,199);
    @Override public void onCreate(Bundle b) { super.onCreate(b); build(); renderEvents(); }
    GradientDrawable bg(int color,int stroke) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(28); d.setStroke(1,stroke); return d;
    }
    TextView text(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    void build() {
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(Color.rgb(9,9,13));
        LinearLayout outer=new LinearLayout(this); outer.setPadding(22,26,22,28); outer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(outer); setContentView(scroll);
        outer.addView(text("COUNTDOWN HUB",14,red,true));
        TextView heading=text("Your countdowns",29,white,true); LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=18;outer.addView(heading,hp);
        outer.addView(text("JEE, NEET, SSC, Diwali, birthdays or any event.",14,muted,false));
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(16,16,16,16); card.setBackground(bg(Color.rgb(20,20,27),Color.rgb(70,35,44)));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=22;outer.addView(card,cp);
        card.addView(text("ADD A COUNTDOWN",12,red,true));
        titleInput=new EditText(this); titleInput.setSingleLine(true);titleInput.setTextColor(white);titleInput.setHintTextColor(muted);titleInput.setHint("Event name (e.g. Diwali / SSC CGL)");
        titleInput.setText("My First Event"); card.addView(titleInput);
        dateButton=new TextView(this);dateButton.setTextColor(white);dateButton.setTextSize(15);dateButton.setPadding(0,16,0,16);card.addView(dateButton); updateDateLabel();
        dateButton.setOnClickListener(v->showPicker());
        Button add=new Button(this);add.setText("＋  Add countdown");add.setTextColor(Color.BLACK);add.setBackgroundTintList(android.content.res.ColorStateList.valueOf(red));card.addView(add);
        add.setOnClickListener(v->{String name=titleInput.getText().toString().trim();if(name.isEmpty()){titleInput.setError("Enter an event name");return;}
            List<EventStore.Event> events=EventStore.get(this);events.add(new EventStore.Event(name,chosenDate));EventStore.save(this,events);
            titleInput.setText(""); renderEvents(); CountdownWidgetProvider.refreshAll(this); Toast.makeText(this,"Countdown added",Toast.LENGTH_SHORT).show();});
        TextView sub=text("SAVED EVENTS",12,red,true);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=25;outer.addView(sub,sp);
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);outer.addView(list);
        TextView note=text("Home-screen widget shows the next upcoming event. Add this widget by long-pressing your home screen → Widgets → JEE Countdown.",12,muted,false);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=20;outer.addView(note,np);
    }
    void showPicker() {
        new DatePickerDialog(this,(v,y,m,d)->{selected.set(y,m,d);chosenDate=String.format(Locale.US,"%04d-%02d-%02d",y,m+1,d);updateDateLabel();},
            selected.get(Calendar.YEAR),selected.get(Calendar.MONTH),selected.get(Calendar.DAY_OF_MONTH)).show();
    }
    void updateDateLabel() {
        try { Date d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(chosenDate);dateButton.setText("📅  "+new SimpleDateFormat("d MMMM yyyy",Locale.ENGLISH).format(d)+"   ✎ Change");}
        catch(Exception e){dateButton.setText("Choose event date");}
    }
    void renderEvents() {
        if(list==null)return; list.removeAllViews();
        List<EventStore.Event> events=EventStore.get(this);
        for(int idx=0;idx<events.size();idx++) {
            final int pos=idx; EventStore.Event e=events.get(idx);
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(14,12,10,12);row.setGravity(android.view.Gravity.CENTER_VERTICAL);row.setBackground(bg(Color.rgb(20,20,27),Color.rgb(43,43,54)));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=9;list.addView(row,rp);
            LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            info.addView(text(e.title,16,white,true));
            String date=e.date;try{date=new SimpleDateFormat("d MMM yyyy",Locale.ENGLISH).format(new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(e.date));}catch(Exception ignored){}
            info.addView(text(date,12,muted,false));
            TextView del=text("✕",18,red,true);del.setPadding(12,8,8,8);row.addView(del);del.setOnClickListener(v->{List<EventStore.Event> now=EventStore.get(this);if(now.size()<=1){Toast.makeText(this,"Keep at least one countdown",Toast.LENGTH_SHORT).show();return;}now.remove(pos);EventStore.save(this,now);renderEvents();CountdownWidgetProvider.refreshAll(this);});
        }
    }
    @Override protected void onResume(){super.onResume();CountdownWidgetProvider.refreshAll(this);}
}
